<?php

/**
 * This is the application Bootstrap which can be customized 
 * depending on the application needs and modules can extend 
 * this class if required. It all depends on the use case.
 */
class Bootstrap extends Zend_Application_Bootstrap_Bootstrap {


}