<?php

class IndexController extends Zend_Controller_Action
{
public $flashMessenger;

    public function init()
    {
        /* Initialize action controller here */
		$this->flashMessenger = $this->_helper->FlashMessenger;
    }

    public function indexAction()
    {
         echo "Index action";
        // action body
         //$modelUser = new Application_Model_User;
         //$Info = $modelUser->getUserInfo();         
        // print_r($Info);
    }
    
    public function registrationAction()
    {
	print_r($_POST);
        
    } 
	 public function manageAction()
    {
	
	$this->view->message = $this->flashMessenger->getMessages();
        
    } 


}

